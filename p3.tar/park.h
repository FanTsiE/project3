#ifndef P3_PARK_H
#define P3_PARK_H

void drawPark();

#endif //P3_PARK_H
